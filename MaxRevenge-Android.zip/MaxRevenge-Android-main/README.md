# Max's Revenge - Android

A 2D action game for Android.
Project: Max's Revenge.
Platform: Android APK.
Development: GitHub Codespaces.

## Current state
Combat prototype ported from the PSP version: movement, jump, sword attack, enemy AI, health bars, victory and defeat with restart.
Shapes only for now. Graphics, sound, and Arabic text come in later passes.

## Build
Option 1: open the project in Android Studio, then Build > Build APK.
Option 2: push to GitHub. The workflow in .github/workflows/build.yml builds app-debug.apk,
which you can download from the Actions tab (Artifacts).
