package com.maxrevenge

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    private val game = Game()
    private val paint = Paint()
    private val buttons = HashMap<String, RectF>()
    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var held: Set<String> = emptySet()
    private var prevHeld: Set<String> = emptySet()

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val fw = w.toFloat()
        val fh = h.toFloat()
        buttons["left"] = RectF(fw * 0.02f, fh * 0.45f, fw * 0.16f, fh * 0.95f)
        buttons["right"] = RectF(fw * 0.18f, fh * 0.45f, fw * 0.32f, fh * 0.95f)
        buttons["attack"] = RectF(fw * 0.68f, fh * 0.45f, fw * 0.82f, fh * 0.95f)
        buttons["jump"] = RectF(fw * 0.84f, fh * 0.45f, fw * 0.98f, fh * 0.95f)
        buttons["restart"] = RectF(fw * 0.40f, fh * 0.05f, fw * 0.60f, fh * 0.22f)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val pressed = HashSet<String>()
        val lifting = event.actionMasked == MotionEvent.ACTION_UP ||
            event.actionMasked == MotionEvent.ACTION_CANCEL
        for (i in 0 until event.pointerCount) {
            if (!lifting && !(event.actionMasked == MotionEvent.ACTION_POINTER_UP && i == event.actionIndex)) {
                val x = event.getX(i)
                val y = event.getY(i)
                for ((name, rect) in buttons) {
                    if (rect.contains(x, y)) pressed.add(name)
                }
            }
        }
        held = pressed
        return true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        thread = Thread(this).also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        thread?.join()
        thread = null
    }

    override fun run() {
        val frameNs = 1_000_000_000L / 60
        while (running) {
            val start = System.nanoTime()
            tick()
            draw()
            val sleepMs = (frameNs - (System.nanoTime() - start)) / 1_000_000
            if (sleepMs > 0) Thread.sleep(sleepMs)
        }
    }

    private fun tick() {
        val now = held
        game.update(
            Input(
                left = "left" in now,
                right = "right" in now,
                jump = "jump" in now && "jump" !in prevHeld,
                attack = "attack" in now && "attack" !in prevHeld,
                restart = "restart" in now && "restart" !in prevHeld
            )
        )
        prevHeld = now
    }

    private fun draw() {
        val canvas = holder.lockCanvas() ?: return
        try {
            render(canvas)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    private fun render(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawColor(Color.BLACK)

        val s = minOf(w / 480f, h / 272f)
        val ox = (w - 480f * s) / 2f
        val oy = (h - 272f * s) / 2f
        canvas.save()
        canvas.translate(ox, oy)
        canvas.scale(s, s)
        drawWorld(canvas)
        canvas.restore()

        drawControls(canvas)
    }

    private fun fill(c: Canvas, x: Float, y: Float, w: Float, h: Float, color: String) {
        paint.color = Color.parseColor(color)
        c.drawRect(x, y, x + w, y + h, paint)
    }

    private fun drawWorld(c: Canvas) {
        fill(c, 0f, 0f, 480f, 272f, "#20202A")

        fill(c, 35f, 155f, 35f, 66f, "#383838")
        fill(c, 395f, 145f, 45f, 76f, "#303030")
        fill(c, 0f, 224f, 480f, 48f, "#292929")
        fill(c, 0f, 221f, 480f, 3f, "#555555")
        fill(c, 0f, 245f, 480f, 2f, "#777777")

        fill(c, 10f, 10f, 150f, 8f, "#333333")
        fill(c, 10f, 10f, 150f * game.maxHP / 100f, 8f, "#22CC55")
        fill(c, 320f, 10f, 150f, 8f, "#333333")
        fill(c, 320f, 10f, 150f * game.enemyHP / 100f, 8f, "#DD2222")
        fill(c, 10f, 24f, 70f, 3f, "#AAAAAA")
        fill(c, 320f, 24f, 70f, 3f, "#AAAAAA")

        drawMax(c)
        if (game.enemyHP > 0) drawEnemy(c)

        when (game.outcome) {
            Outcome.WIN -> {
                fill(c, 125f, 105f, 230f, 5f, "#22CC55")
                fill(c, 155f, 120f, 170f, 4f, "#FFFFFF")
                drawBanner(c, "Victory")
            }
            Outcome.LOSE -> {
                fill(c, 125f, 105f, 230f, 5f, "#DD2222")
                fill(c, 155f, 120f, 170f, 4f, "#FFFFFF")
                drawBanner(c, "Defeat - tap Restart")
            }
            null -> {}
        }
    }

    private fun drawBanner(c: Canvas, text: String) {
        paint.color = Color.WHITE
        paint.textSize = 18f
        paint.textAlign = Paint.Align.CENTER
        c.drawText(text, 240f, 95f, paint)
        paint.textAlign = Paint.Align.LEFT
    }

    private fun drawMax(c: Canvas) {
        val x = game.maxX
        val y = 188f - game.maxY
        val body = if (game.hurtFrames > 0) "#FF7777" else "#333333"
        fill(c, x + 10f, y + 40f, 22f, 22f, "#151515")
        fill(c, x + 7f, y + 57f, 12f, 7f, "#080808")
        fill(c, x + 24f, y + 57f, 12f, 7f, "#080808")
        fill(c, x + 8f, y + 15f, 28f, 28f, body)
        fill(c, x + 12f, y + 2f, 20f, 16f, "#B98A68")
        fill(c, x + 7f, y + 14f, 30f, 5f, "#AA2222")
        if (game.attackFrames > 0) {
            if (game.facing > 0) fill(c, x + 30f, y + 26f, 43f, 5f, "#DDDDDD")
            else fill(c, x - 37f, y + 26f, 43f, 5f, "#DDDDDD")
        } else {
            if (game.facing > 0) fill(c, x + 31f, y + 28f, 22f, 4f, "#BBBBBB")
            else fill(c, x - 15f, y + 28f, 22f, 4f, "#BBBBBB")
        }
    }

    private fun drawEnemy(c: Canvas) {
        val x = game.enemyX
        val body = if (game.flashFrames > 0) "#FFFFFF" else "#252575"
        fill(c, x + 7f, 190f, 30f, 27f, body)
        fill(c, x + 3f, 214f, 13f, 8f, "#101010")
        fill(c, x + 27f, 214f, 13f, 8f, "#101010")
        fill(c, x + 12f, 175f, 21f, 17f, "#777777")
        fill(c, x + 8f, 174f, 28f, 5f, "#111111")
        fill(c, x + 10f, 181f, 5f, 3f, "#2222FF")
        fill(c, x + 28f, 181f, 5f, 3f, "#2222FF")
    }

    private fun drawControls(c: Canvas) {
        val labels = mapOf(
            "left" to "Left", "right" to "Right",
            "jump" to "Jump", "attack" to "Attack", "restart" to "Restart"
        )
        for ((name, rect) in buttons) {
            if (name == "restart" && game.outcome == null) continue
            paint.color = if (name in held) Color.argb(140, 255, 255, 255) else Color.argb(60, 255, 255, 255)
            c.drawRoundRect(rect, 24f, 24f, paint)
            paint.color = Color.WHITE
            paint.textSize = rect.height() * 0.28f
            paint.textAlign = Paint.Align.CENTER
            c.drawText(labels[name] ?: name, rect.centerX(), rect.centerY() + paint.textSize / 3f, paint)
        }
        paint.textAlign = Paint.Align.LEFT
    }
}
