package com.maxrevenge

import kotlin.math.abs

data class Input(
    val left: Boolean,
    val right: Boolean,
    val jump: Boolean,
    val attack: Boolean,
    val restart: Boolean
)

enum class Outcome { WIN, LOSE }

class Game {
    var maxX = 105f; private set
    var maxY = 0f; private set
    var maxVY = 0f; private set
    var facing = 1; private set
    var maxHP = 100; private set
    var enemyX = 345f; private set
    var enemyHP = 100; private set
    var attackFrames = 0; private set
    var attackCooldown = 0; private set
    var hurtFrames = 0; private set
    var flashFrames = 0; private set
    var outcome: Outcome? = null; private set

    fun reset() {
        maxX = 105f; maxY = 0f; maxVY = 0f; facing = 1
        maxHP = 100; enemyX = 345f; enemyHP = 100
        attackFrames = 0; attackCooldown = 0; hurtFrames = 0; flashFrames = 0
        outcome = null
    }

    fun update(input: Input) {
        if (outcome != null) {
            if (input.restart) reset()
            return
        }

        val dx = (if (input.right) 3f else 0f) - (if (input.left) 3f else 0f)
        if (dx > 0f) facing = 1
        if (dx < 0f) facing = -1
        maxX = (maxX + dx).coerceIn(5f, 425f)

        if (input.jump && maxY <= 0.1f) maxVY = 8.2f
        maxY += maxVY
        maxVY -= 0.42f
        if (maxY < 0f) { maxY = 0f; maxVY = 0f }

        if (attackCooldown > 0) attackCooldown--
        if (attackFrames > 0) attackFrames--
        if (hurtFrames > 0) hurtFrames--
        if (flashFrames > 0) flashFrames--

        if (input.attack && attackCooldown == 0) {
            attackFrames = 9
            attackCooldown = 22
            val d = enemyX - maxX
            if ((facing > 0 && d >= 0f && d < 92f) || (facing < 0 && d < 0f && d > -55f)) {
                enemyHP = (enemyHP - 25).coerceAtLeast(0)
                flashFrames = 6
            }
        }

        if (enemyHP > 0) {
            if (enemyX > maxX + 48f) enemyX -= 0.35f
            if (enemyX < maxX + 24f) enemyX += 0.35f
            if (abs(enemyX - maxX) < 43f && hurtFrames == 0) {
                maxHP = (maxHP - 1).coerceAtLeast(0)
                hurtFrames = 18
            }
        }

        outcome = when {
            enemyHP == 0 -> Outcome.WIN
            maxHP == 0 -> Outcome.LOSE
            else -> null
        }
    }
}
